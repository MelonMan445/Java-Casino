
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

/**
 * 
 */
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Window that displays all cards in a deck
 */
public class ViewCardsWindow extends JFrame {
	private JPanel cardsDisplayPanel;
	private JButton viewCardsButton;

	public ViewCardsWindow() {
		setTitle("View Cards");
		setSize(900, 650);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout());

		// Main panel to display cards (green felt background)
		cardsDisplayPanel = new JPanel();
		cardsDisplayPanel.setLayout(new GridLayout(4, 13, 10, 10)); // 4 suits, 13 cards each
		cardsDisplayPanel.setBackground(new Color(0, 100, 0));

		JScrollPane scrollPane = new JScrollPane(cardsDisplayPanel);
		add(scrollPane, BorderLayout.CENTER);

		// Bottom panel with button aligned to the right
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		viewCardsButton = new JButton("View Cards");
		viewCardsButton.addActionListener(e -> dealAndDisplayCards());
		bottomPanel.add(viewCardsButton);
		add(bottomPanel, BorderLayout.SOUTH);

		setVisible(true);
	}

	/**
	 * Deals all cards from a new deck and displays them
	 */
	private void dealAndDisplayCards() {
		// Clear previous cards
		cardsDisplayPanel.removeAll();

		// Create and shuffle new deck
		Deck deck = new Deck();
		deck.new_deck();
		deck.shuffle();

		// Deal all 52 cards from top of deck
		for (int i = 0; i < 52; i++) {
			Cards dealtCard = deck.deal(deck);
			if (dealtCard != null) {
				CardPanel cardPanel = new CardPanel(dealtCard);
				cardsDisplayPanel.add(cardPanel);
			}
		}

		// Refresh the display
		cardsDisplayPanel.revalidate();
		cardsDisplayPanel.repaint();
	}
}