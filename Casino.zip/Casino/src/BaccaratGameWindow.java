
/**
 * @author Jonathan Laporte
 * @version 2025-12-24
 */

/**
 * 
 */
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class BaccaratGameWindow extends JFrame {
	// Game state
	private Player player;
	private Deck deck;
	private ArrayList<Cards> playerHand;
	private ArrayList<Cards> bankerHand;
	private int wagerAmount;
	private String betType; // "PLAYER", "BANKER", or "TIE"

	// UI Components
	private JPanel playerHandPanel;
	private JPanel bankerHandPanel;
	private JLabel playerTotalLabel;
	private JLabel bankerTotalLabel;
	private JLabel balanceLabel;
	private JLabel messageLabel;
	private JLabel cardsLeftLabel;
	private JButton playerBetButton;
	private JButton bankerBetButton;
	private JButton tieBetButton;
	private JTextField wagerField;

	public BaccaratGameWindow(Player player) {
		this.player = player;
		this.deck = createBaccaratDeck();
		this.playerHand = new ArrayList<>();
		this.bankerHand = new ArrayList<>();
		initializeUI();
	}

	private void initializeUI() {
		setupFrame();
		add(createTopPanel(), BorderLayout.NORTH);
		add(createCenterPanel(), BorderLayout.CENTER);
		add(createBottomPanel(), BorderLayout.SOUTH);
		setVisible(true);
	}

	private void setupFrame() {
		setTitle("Baccarat - Punto Banco");
		setSize(900, 650);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout(10, 10));
	}

	private JPanel createTopPanel() {
		JPanel panel = new JPanel(new GridLayout(1, 2, 20, 0));
		panel.setBackground(new Color(0, 100, 0));

		// Banker side
		JPanel bankerPanel = new JPanel(new BorderLayout());
		bankerPanel.setBackground(new Color(0, 100, 0));

		JLabel bankerLabel = new JLabel("BANKER", SwingConstants.CENTER);
		bankerLabel.setFont(new Font("Arial", Font.BOLD, 20));
		bankerLabel.setForeground(Color.WHITE);
		bankerPanel.add(bankerLabel, BorderLayout.NORTH);

		bankerHandPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		bankerHandPanel.setBackground(new Color(0, 100, 0));
		bankerHandPanel.setPreferredSize(new Dimension(400, 150));
		bankerPanel.add(bankerHandPanel, BorderLayout.CENTER);

		bankerTotalLabel = new JLabel("Total: -", SwingConstants.CENTER);
		bankerTotalLabel.setFont(new Font("Arial", Font.BOLD, 18));
		bankerTotalLabel.setForeground(Color.YELLOW);
		bankerPanel.add(bankerTotalLabel, BorderLayout.SOUTH);

		// Player side
		JPanel playerPanel = new JPanel(new BorderLayout());
		playerPanel.setBackground(new Color(0, 100, 0));

		JLabel playerLabel = new JLabel("PLAYER", SwingConstants.CENTER);
		playerLabel.setFont(new Font("Arial", Font.BOLD, 20));
		playerLabel.setForeground(Color.WHITE);
		playerPanel.add(playerLabel, BorderLayout.NORTH);

		playerHandPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		playerHandPanel.setBackground(new Color(0, 100, 0));
		playerHandPanel.setPreferredSize(new Dimension(400, 150));
		playerPanel.add(playerHandPanel, BorderLayout.CENTER);

		playerTotalLabel = new JLabel("Total: -", SwingConstants.CENTER);
		playerTotalLabel.setFont(new Font("Arial", Font.BOLD, 18));
		playerTotalLabel.setForeground(Color.YELLOW);
		playerPanel.add(playerTotalLabel, BorderLayout.SOUTH);

		panel.add(bankerPanel);
		panel.add(playerPanel);

		return panel;
	}

	private JPanel createCenterPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 120, 0));

		balanceLabel = new JLabel("Balance: $" + String.format("%.2f", player.balance), SwingConstants.CENTER);
		balanceLabel.setFont(new Font("Arial", Font.BOLD, 24));
		balanceLabel.setForeground(Color.YELLOW);
		panel.add(balanceLabel, BorderLayout.NORTH);

		messageLabel = new JLabel("Place your bet!", SwingConstants.CENTER);
		messageLabel.setFont(new Font("Arial", Font.BOLD, 20));
		messageLabel.setForeground(Color.WHITE);
		panel.add(messageLabel, BorderLayout.CENTER);

		cardsLeftLabel = new JLabel("Cards in Shoe: " + deck.cards.size(), SwingConstants.CENTER);
		cardsLeftLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		cardsLeftLabel.setForeground(Color.CYAN);
		panel.add(cardsLeftLabel, BorderLayout.SOUTH);

		return panel;
	}

	private JPanel createBottomPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 100, 0));

		JPanel bettingPanel = createBettingPanel();
		panel.add(bettingPanel, BorderLayout.CENTER);

		return panel;
	}

	private JPanel createBettingPanel() {
		JPanel panel = new JPanel(new FlowLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel wagerLabel = new JLabel("Wager Amount: $");
		wagerLabel.setForeground(Color.WHITE);
		wagerLabel.setFont(new Font("Arial", Font.BOLD, 14));
		panel.add(wagerLabel);

		wagerField = new JTextField("10", 10);
		panel.add(wagerField);

		playerBetButton = new JButton("Bet on PLAYER (1:1)");
		playerBetButton.setFont(new Font("Arial", Font.BOLD, 14));
		playerBetButton.setBackground(new Color(70, 130, 180));
		playerBetButton.setForeground(Color.WHITE);
		playerBetButton.addActionListener(e -> placeBet("PLAYER"));
		panel.add(playerBetButton);

		bankerBetButton = new JButton("Bet on BANKER (0.95:1)");
		bankerBetButton.setFont(new Font("Arial", Font.BOLD, 14));
		bankerBetButton.setBackground(new Color(178, 34, 34));
		bankerBetButton.setForeground(Color.WHITE);
		bankerBetButton.addActionListener(e -> placeBet("BANKER"));
		panel.add(bankerBetButton);

		tieBetButton = new JButton("Bet on TIE (8:1)");
		tieBetButton.setFont(new Font("Arial", Font.BOLD, 14));
		tieBetButton.setBackground(new Color(85, 107, 47));
		tieBetButton.setForeground(Color.WHITE);
		tieBetButton.addActionListener(e -> placeBet("TIE"));
		panel.add(tieBetButton);

		return panel;
	}

	private void placeBet(String type) {
		if (!validateWager()) {
			return;
		}

		betType = type;
		player.balance -= wagerAmount;
		updateBalanceAndSave();

		disableBettingButtons();
		checkAndReshuffleDeck();
		resetHands();

		messageLabel.setText("You bet $" + wagerAmount + " on " + betType);

		Timer startTimer = new Timer(1500, e -> startGame());
		startTimer.setRepeats(false);
		startTimer.start();
	}

	private boolean validateWager() {
		try {
			double wager = Double.parseDouble(wagerField.getText());
			if (wager <= 0) {
				showError("Wager must be positive!");
				return false;
			}
			if (wager > player.balance) {
				showError("Insufficient balance!");
				return false;
			}
			wagerAmount = (int) wager;
			return true;
		} catch (NumberFormatException e) {
			showError("Invalid wager amount!");
			return false;
		}
	}

	private void checkAndReshuffleDeck() {
		if (deck.cards.size() < 8) {
			this.deck = createBaccaratDeck();
			messageLabel.setText("New 8-deck shoe!");
			updateCardsLeft();
		}
	}

	private void resetHands() {
		playerHand.clear();
		bankerHand.clear();
		playerHandPanel.removeAll();
		bankerHandPanel.removeAll();
		playerTotalLabel.setText("Total: -");
		bankerTotalLabel.setText("Total: -");
	}

	private void startGame() {
		messageLabel.setText("Dealing cards...");
		animateInitialDeal();
	}

	private void animateInitialDeal() {
		Timer dealTimer = new Timer(800, null);
		final int[] step = { 0 };

		dealTimer.addActionListener(e -> {
			if (step[0] == 0) {
				dealCardToPlayer();
				step[0]++;
			} else if (step[0] == 1) {
				dealCardToBanker();
				step[0]++;
			} else if (step[0] == 2) {
				dealCardToPlayer();
				step[0]++;
			} else if (step[0] == 3) {
				dealCardToBanker();
				step[0]++;
			} else {
				dealTimer.stop();
				checkNaturals();
			}
		});

		dealTimer.start();
	}

	private void dealCardToPlayer() {
		Cards card = deck.deal(deck);
		playerHand.add(card);
		updateCardsLeft();
		displayPlayerHand();
	}

	private void dealCardToBanker() {
		Cards card = deck.deal(deck);
		bankerHand.add(card);
		updateCardsLeft();
		displayBankerHand();
	}

	private void checkNaturals() {
		int playerTotal = calculateTotal(playerHand);
		int bankerTotal = calculateTotal(bankerHand);

		if (playerTotal >= 8 || bankerTotal >= 8) {
			messageLabel.setText("Natural! No more cards drawn.");
			Timer timer = new Timer(2000, e -> resolveGame());
			timer.setRepeats(false);
			timer.start();
		} else {
			applyDrawingRules();
		}
	}

	private void applyDrawingRules() {
		int playerTotal = calculateTotal(playerHand);
		int bankerTotal = calculateTotal(bankerHand);

		messageLabel.setText("Applying drawing rules...");

		Timer ruleTimer = new Timer(1500, null);
		final boolean[] playerDrew = { false };
		final int[] playerThirdCardValue = { -1 };

		ruleTimer.addActionListener(e -> {
			// Player draws if 0-5, stands on 6-7
			if (!playerDrew[0] && playerTotal <= 5) {
				messageLabel.setText("Player draws third card...");
				dealCardToPlayer();
				playerThirdCardValue[0] = playerHand.get(2).worth;
				playerDrew[0] = true;

			} else if (!playerDrew[0]) {
				// Player stands
				playerDrew[0] = true;
				messageLabel.setText("Player stands on " + playerTotal);

			} else {
				// Now check banker rules
				boolean bankerDraws = shouldBankerDraw(bankerTotal, playerDrew[0], playerThirdCardValue[0]);

				if (bankerDraws) {
					messageLabel.setText("Banker draws third card...");
					dealCardToBanker();
				} else {
					messageLabel.setText("Banker stands on " + bankerTotal);
				}

				ruleTimer.stop();
				Timer resolveTimer = new Timer(2000, ev -> resolveGame());
				resolveTimer.setRepeats(false);
				resolveTimer.start();
			}
		});

		ruleTimer.start();
	}

	private boolean shouldBankerDraw(int bankerTotal, boolean playerDrewThird, int playerThirdValue) {
		if (!playerDrewThird) {
			// Player stood, banker draws on 0-5, stands on 6-7
			return bankerTotal <= 5;
		}

		// Player drew a third card, apply complex rules
		if (bankerTotal <= 2) {
			return true;
		}
		if (bankerTotal == 3) {
			return playerThirdValue != 8;
		}
		if (bankerTotal == 4) {
			return playerThirdValue >= 2 && playerThirdValue <= 7;
		}
		if (bankerTotal == 5) {
			return playerThirdValue >= 4 && playerThirdValue <= 7;
		}
		if (bankerTotal == 6) {
			return playerThirdValue == 6 || playerThirdValue == 7;
		}
		return false;
	}

	private void resolveGame() {
		int playerTotal = calculateTotal(playerHand);
		int bankerTotal = calculateTotal(bankerHand);

		String result;
		double payout = 0;

		if (playerTotal > bankerTotal) {
			result = "PLAYER WINS! (" + playerTotal + " vs " + bankerTotal + ")";
			if (betType.equals("PLAYER")) {
				payout = wagerAmount * 2; // 1:1 payout
				messageLabel.setText("🎉 " + result + " You win $" + wagerAmount + "!");
				messageLabel.setForeground(Color.GREEN);
			} else {
				messageLabel.setText(result + " You lose.");
				messageLabel.setForeground(Color.RED);
			}
		} else if (bankerTotal > playerTotal) {
			result = "BANKER WINS! (" + bankerTotal + " vs " + playerTotal + ")";
			if (betType.equals("BANKER")) {
				payout = wagerAmount + (int) (wagerAmount * 0.95); // 0.95:1 payout (5% commission)
				messageLabel.setText("🎉 " + result + " You win $" + (int) (wagerAmount * 0.95) + "!");
				messageLabel.setForeground(Color.GREEN);
			} else {
				messageLabel.setText(result + " You lose.");
				messageLabel.setForeground(Color.RED);
			}
		} else {
			result = "TIE! (" + playerTotal + " vs " + bankerTotal + ")";
			if (betType.equals("TIE")) {
				payout = wagerAmount * 9; // 8:1 payout plus original bet
				messageLabel.setText("🎉 " + result + " You win $" + (wagerAmount * 8) + "!");
				messageLabel.setForeground(Color.GREEN);
			} else {
				payout = wagerAmount; // Push - return bet
				messageLabel.setText(result + " Bet returned.");
				messageLabel.setForeground(Color.YELLOW);
			}
		}

		player.balance += payout;
		updateBalanceAndSave();
		enableBettingButtons();
	}

	private int calculateTotal(ArrayList<Cards> hand) {
		int total = 0;
		for (Cards card : hand) {
			total += card.worth;
		}
		return total % 10;
	}

	private void displayPlayerHand() {
		playerHandPanel.removeAll();
		for (Cards card : playerHand) {
			playerHandPanel.add(new CardPanel(card));
		}
		playerTotalLabel.setText("Total: " + calculateTotal(playerHand));
		playerHandPanel.revalidate();
		playerHandPanel.repaint();
	}

	private void displayBankerHand() {
		bankerHandPanel.removeAll();
		for (Cards card : bankerHand) {
			bankerHandPanel.add(new CardPanel(card));
		}
		bankerTotalLabel.setText("Total: " + calculateTotal(bankerHand));
		bankerHandPanel.revalidate();
		bankerHandPanel.repaint();
	}

	private Deck createBaccaratDeck() {
		Deck baccaratDeck = new Deck();
		baccaratDeck.cards.clear();

		String[] types = { "♥", "♦", "♠", "♣" };
		String[] display = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
		int[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0 }; // Baccarat values

		// Create 8 decks
		for (int deck = 0; deck < 8; deck++) {
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 13; j++) {
					Cards card = new Cards(values[j], types[i], display[j]);
					baccaratDeck.cards.add(card);
				}
			}
		}

		baccaratDeck.shuffle();
		return baccaratDeck;
	}

	private void disableBettingButtons() {
		playerBetButton.setEnabled(false);
		bankerBetButton.setEnabled(false);
		tieBetButton.setEnabled(false);
		wagerField.setEnabled(false);
	}

	private void enableBettingButtons() {
		Timer timer = new Timer(3000, e -> {
			playerBetButton.setEnabled(true);
			bankerBetButton.setEnabled(true);
			tieBetButton.setEnabled(true);
			wagerField.setEnabled(true);
			messageLabel.setText("Place your bet!");
			messageLabel.setForeground(Color.WHITE);
		});
		timer.setRepeats(false);
		timer.start();
	}

	private void showError(String message) {
		JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void updateBalanceAndSave() {
		try {
			player.updateBalance(player.balance);
			balanceLabel.setText("Balance: $" + String.format("%.2f", player.balance));
		} catch (Exception e) {
			messageLabel.setText("Error saving balance!");
			e.printStackTrace();
		}
	}

	private void updateCardsLeft() {
		cardsLeftLabel.setText("Cards in Shoe: " + deck.cards.size());
	}
}
