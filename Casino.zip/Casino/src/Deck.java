
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

/**
 * ArrayList<Integer> list = new ArrayList<>();
list.add(1);        // Add elements
list.add(2);
list.get(0);        // Access: returns 1
list.size();        // Get size
list.remove(0);     // Remove element





Random rand = new Random();

// Generate random integers
int randomInt = rand.nextInt();              // Any int (positive or negative)
int zeroToNine = rand.nextInt(10);           // 0 to 9 (exclusive upper bound)
int oneToTen = rand.nextInt(10) + 1;         // 1 to 10
int fiveToFifteen = rand.nextInt(11) + 5;    // 5 to 15 (range of 11, start at 5)
 */
import java.util.ArrayList;
import java.util.Random;

public class Deck {
	public ArrayList<Cards> cards = new ArrayList<>();
	Random rand = new Random();

	public void shuffle() {
		for (int i = 0; i < cards.size(); i++) {
			int rand_index1 = rand.nextInt(cards.size());
			int rand_index2 = rand.nextInt(cards.size());

			do {
				rand_index2 = rand.nextInt(cards.size());
			} while (rand_index2 == rand_index1);

			Cards temp = cards.get(rand_index1);
			cards.set(rand_index1, cards.get(rand_index2));
			cards.set(rand_index2, temp);
		}

	}

	public void new_deck() {
		this.cards.clear();
		String[] types = { "♥", "♦", "♠", "♣" };
		String[] display = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 13; j++) {
				Cards card = new Cards(j, types[i], display[j]);
				this.cards.add(card);
			}
		}

	}

	public Cards deal(Deck deck) {
		if (deck.cards.size() > 0) {
			return deck.cards.remove(0);
		}
		return null;
	}

}
