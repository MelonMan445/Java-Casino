
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class Main_Menu extends JFrame {
	private Player logged_in_player;
	private JTextField usernameField;
	private JPasswordField passwordField;

	public Main_Menu() {
		initializeUI();
	}

	public static ArrayList<Player> player_list() {
		ArrayList<Player> players = new ArrayList<>();

		try {
			BufferedReader reader = new BufferedReader(new FileReader("Player_info.txt"));
			String line;

			while ((line = reader.readLine()) != null) {
				if (!line.trim().isEmpty()) {
					String[] parts = line.split(",");
					String name = parts[0];
					String hashedPassword = parts[1];
					String salt = parts[2];
					double balance = Double.parseDouble(parts[3]);

					Player player = new Player(name, hashedPassword, salt, balance);
					players.add(player);
				}
			}
			reader.close();
		} catch (Exception e) {
			// File doesn't exist or is empty - that's okay, just return empty list
			// This means there are no existing players yet
		}

		return players;
	}

	private void initializeUI() {
		setTitle("Casino - Login");
		setSize(400, 250);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout(10, 10));

		JPanel titlePanel = new JPanel();
		JLabel titleLabel = new JLabel("🎰 Welcome to the Casino 🎰");
		titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
		titlePanel.add(titleLabel);
		add(titlePanel, BorderLayout.NORTH);

		JPanel centerPanel = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5, 5, 5, 5);
		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.gridx = 0;
		gbc.gridy = 0;
		centerPanel.add(new JLabel("Username:"), gbc);

		gbc.gridx = 1;
		usernameField = new JTextField(15);
		centerPanel.add(usernameField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		centerPanel.add(new JLabel("Password:"), gbc);

		gbc.gridx = 1;
		passwordField = new JPasswordField(15);
		centerPanel.add(passwordField, gbc);

		add(centerPanel, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel(new FlowLayout());

		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(e -> handleLogin());
		buttonPanel.add(loginButton);

		JButton newUserButton = new JButton("New User");
		newUserButton.addActionListener(e -> openRegistrationWindow());
		buttonPanel.add(newUserButton);

		add(buttonPanel, BorderLayout.SOUTH);

		passwordField.addActionListener(e -> handleLogin());
	}

	private void handleLogin() {
		String username = usernameField.getText().trim();
		String password = new String(passwordField.getPassword());

		if (username.isEmpty() || password.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter both username and password!", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		ArrayList<Player> players = player_list();

		Player foundPlayer = null;
		for (Player p : players) {
			if (p.name.equals(username)) {
				foundPlayer = p;
				break;
			}
		}

		if (foundPlayer == null) {
			JOptionPane.showMessageDialog(this, "Username not found!", "Login Failed", JOptionPane.ERROR_MESSAGE);
			passwordField.setText("");
			return;
		}

		if (foundPlayer.verifyPassword(password)) {
			logged_in_player = foundPlayer;
			JOptionPane.showMessageDialog(this,
					"Welcome back, " + foundPlayer.name + "!\nBalance: $" + foundPlayer.balance, "Login Successful",
					JOptionPane.INFORMATION_MESSAGE);

			openCasinoWindow();
		} else {
			JOptionPane.showMessageDialog(this, "Incorrect password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
			passwordField.setText("");
		}
	}

	private void openRegistrationWindow() {
		JFrame regFrame = new JFrame("New User Registration");
		regFrame.setSize(400, 250);
		regFrame.setLocationRelativeTo(this);
		regFrame.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);
		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.gridx = 0;
		gbc.gridy = 0;
		regFrame.add(new JLabel("Username:"), gbc);

		gbc.gridx = 1;
		JTextField regUsernameField = new JTextField(15);
		regFrame.add(regUsernameField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		regFrame.add(new JLabel("Password:"), gbc);

		gbc.gridx = 1;
		JPasswordField regPasswordField = new JPasswordField(15);
		regFrame.add(regPasswordField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 2;
		regFrame.add(new JLabel("Starting Balance:"), gbc);

		gbc.gridx = 1;
		JTextField balanceField = new JTextField("1000.0", 15);
		regFrame.add(balanceField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;

		JButton registerButton = new JButton("Register");
		registerButton.addActionListener(e -> {
			String username = regUsernameField.getText().trim();
			String password = new String(regPasswordField.getPassword());
			String balanceText = balanceField.getText().trim();

			if (username.isEmpty() || password.isEmpty()) {
				JOptionPane.showMessageDialog(regFrame, "Username and password cannot be empty!", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			double balance;
			try {
				balance = Double.parseDouble(balanceText);
				if (balance < 0) {
					JOptionPane.showMessageDialog(regFrame, "Balance must be positive!", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(regFrame, "Invalid balance amount!", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}

			ArrayList<Player> players = player_list();

			for (Player p : players) {
				if (p.name.equals(username)) {
					JOptionPane.showMessageDialog(regFrame,
							"Username already exists! Please choose a different username.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
			}

			try {
				Player.Player_write(balance, username, password);

				JOptionPane.showMessageDialog(regFrame, "Registration successful!\nYou can now login.", "Success",
						JOptionPane.INFORMATION_MESSAGE);
				regFrame.dispose();
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(regFrame, "Error saving player to file!", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		regFrame.add(registerButton, gbc);
		regFrame.setVisible(true);
	}

	private void openCasinoWindow() {
		JFrame casinoFrame = new JFrame("Casino - Game Selection");
		casinoFrame.setSize(600, 400);
		casinoFrame.setLocationRelativeTo(this);
		casinoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel(new BorderLayout());

		JLabel welcomeLabel = new JLabel(
				"Welcome, " + logged_in_player.name + "! Balance: $" + logged_in_player.balance);
		welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
		welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(welcomeLabel, BorderLayout.NORTH);

		JPanel gamePanel = new JPanel(new FlowLayout());

		JButton warButton = new JButton("Play War");
		warButton.addActionListener(e -> {
			casinoFrame.dispose();
			openWarGame();
		});
		gamePanel.add(warButton);

		JButton bjButton = new JButton("Play Black Jack");
		bjButton.addActionListener(e -> {
			casinoFrame.dispose();
			openbjGame();
		});
		gamePanel.add(bjButton);

		JButton bcButton = new JButton("Play Baccarat");
		bcButton.addActionListener(e -> {
			casinoFrame.dispose();
			openbcGame();
		});
		gamePanel.add(bcButton);

		JButton viewCardsButton = new JButton("View Cards");
		viewCardsButton.addActionListener(e -> new ViewCardsWindow());
		gamePanel.add(viewCardsButton);

		panel.add(gamePanel, BorderLayout.CENTER);

		casinoFrame.add(panel);
		casinoFrame.setVisible(true);

		this.setVisible(false);
	}

	private void openbjGame() {
		BlackjackGameWindow bjWindow = new BlackjackGameWindow(logged_in_player);
		bjWindow.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosed(java.awt.event.WindowEvent windowEvent) {
				reopenCasinoWindow();
			}
		});
	}

	private void openWarGame() {
		WarGameWindow warWindow = new WarGameWindow(logged_in_player);
		warWindow.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosed(java.awt.event.WindowEvent windowEvent) {
				reopenCasinoWindow();
			}
		});
	}

	private void openbcGame() {
		BaccaratGameWindow bcWindow = new BaccaratGameWindow(logged_in_player);
		bcWindow.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosed(java.awt.event.WindowEvent windowEvent) {
				reopenCasinoWindow();
			}
		});
	}

	private void reopenCasinoWindow() {
		// Reload player data from file to get updated balance
		ArrayList<Player> players = player_list();
		for (Player p : players) {
			if (p.name.equals(logged_in_player.name)) {
				logged_in_player = p;
				break;
			}
		}
		openCasinoWindow();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			Main_Menu menu = new Main_Menu();
			menu.setVisible(true);
		});
	}
}