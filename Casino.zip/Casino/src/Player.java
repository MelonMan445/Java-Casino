
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

/**
 * 
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Random;

public class Player {
	double balance;
	String name;
	String password;
	String salt;

	public static void Player_write(double balance, String name, String password) throws Exception {
		Player player = new Player(balance, name, password);
		player.save_to_file();
	}

	public Player(double balance, String name, String password) {
		this.name = name;
		this.balance = balance;
		this.salt = generateSalt();
		this.password = hash(password);

	}

	public Player(String name, String hashedPassword, String salt, double balance) {
		this.name = name;
		this.password = hashedPassword;
		this.salt = salt;
		this.balance = balance;
	}

	private String generateSalt() {
		Random rand = new Random();
		StringBuilder salt = new StringBuilder();
		for (int i = 0; i < 16; i++) {

			int randomChar = rand.nextInt(62);
			if (randomChar < 10) {
				salt.append((char) ('0' + randomChar));
			} else if (randomChar < 36) {
				salt.append((char) ('a' + randomChar - 10));
			} else {
				salt.append((char) ('A' + randomChar - 36));
			}
		}
		return salt.toString();
	}

	public String hash(String password) {

		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			return Base64.getEncoder().encodeToString(md.digest((password + this.salt).getBytes()));
		} catch (Exception e) {
			return null;
		}

	}

	public boolean verifyPassword(String enteredPassword) {
		String hashedEntered = hash(enteredPassword);
		return hashedEntered.equals(this.password);
	}

	public String toFileLine() {
		return name + "," + password + "," + salt + "," + balance;
	}

	void save_to_file() throws Exception {
		BufferedWriter writer = new BufferedWriter(new FileWriter("Player_info.txt", true));
		writer.write(this.toFileLine());
		writer.newLine();
		writer.close();
	}

	public void updateBalance(double newBalance) throws Exception {
		this.balance = newBalance;

		// Read all players from file
		ArrayList<Player> players = player_list();

		// Update this player's balance in the list
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).name.equals(this.name)) {
				players.set(i, this);
				break;
			}
		}

		// Write all players back to file
		BufferedWriter writer = new BufferedWriter(new FileWriter("Player_info.txt", false));
		for (Player p : players) {
			writer.write(p.toFileLine());
			writer.newLine();
		}
		writer.close();
	}

	public static ArrayList<Player> player_list() throws Exception {
		ArrayList<Player> players = new ArrayList<>();

		BufferedReader reader = new BufferedReader(new FileReader("Player_info.txt"));
		String line;

		while ((line = reader.readLine()) != null) {
			if (!line.trim().isEmpty()) {
				String[] parts = line.split(",");
				String name = parts[0];
				String hashedPassword = parts[1];
				String salt = parts[2];
				double balance = Double.parseDouble(parts[3]);

				Player player = new Player(name, hashedPassword, salt, balance);
				players.add(player);
			}
		}
		reader.close();

		return players;
	}

}
