
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

/**
 * 
 */
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 * Reusable panel for displaying a single card graphically
 */
public class CardPanel extends JPanel {
	private Cards card;
	private static final int CARD_WIDTH = 80;
	private static final int CARD_HEIGHT = 120;

	public CardPanel(Cards card) {
		this.card = card;
		setPreferredSize(new Dimension(CARD_WIDTH, CARD_HEIGHT));
		setBackground(Color.WHITE);
		setBorder(new LineBorder(Color.BLACK, 2));
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		// Determine color based on suit
		Color suitColor = Color.BLACK;
		if (card.type.equals("♥") || card.type.equals("♦")) {
			suitColor = Color.RED;
		}

		// Draw card value and suit in the center
		g2d.setColor(suitColor);
		g2d.setFont(new Font("Arial", Font.BOLD, 36));

		String cardText = card.display_char + card.type;

		// Center the text
		int textWidth = g2d.getFontMetrics().stringWidth(cardText);
		int textHeight = g2d.getFontMetrics().getHeight();
		int x = (CARD_WIDTH - textWidth) / 2;
		int y = (CARD_HEIGHT + textHeight) / 2 - 5;

		g2d.drawString(cardText, x, y);

		// Draw small suit symbol in top-left corner
		g2d.setFont(new Font("Arial", Font.PLAIN, 16));
		g2d.drawString(card.display_char, 5, 18);
		g2d.setFont(new Font("Arial", Font.PLAIN, 14));
		g2d.drawString(card.type, 5, 32);

		// Draw small suit symbol in bottom-right corner
		g2d.setFont(new Font("Arial", Font.PLAIN, 16));
		g2d.drawString(card.display_char, CARD_WIDTH - 20, CARD_HEIGHT - 20);
		g2d.setFont(new Font("Arial", Font.PLAIN, 14));
		g2d.drawString(card.type, CARD_WIDTH - 20, CARD_HEIGHT - 6);
	}
}
