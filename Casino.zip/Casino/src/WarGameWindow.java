
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class WarGameWindow extends JFrame {
	// Game state
	private Player player;
	private Deck deck;
	private int currentWager;
	private Cards dealerCard;
	private Cards playerCard;

	// UI Components
	private JPanel dealerCardPanel;
	private JPanel playerCardPanel;
	private JLabel balanceLabel;
	private JLabel wagerLabel;
	private JLabel messageLabel;
	private JLabel cardsLeftLabel;
	private JButton dealButton;
	private JButton continueWarButton;
	private JButton surrenderButton;
	private JTextField wagerField;

	public WarGameWindow(Player player) {
		this.player = player;
		this.deck = createWarDeck();
		initializeUI();
	}

	private void initializeUI() {
		setupFrame();
		add(createDealerPanel(), BorderLayout.NORTH);
		add(createCenterPanel(), BorderLayout.CENTER);
		add(createPlayerPanel(), BorderLayout.SOUTH);
		setVisible(true);
	}

	private void setupFrame() {
		setTitle("War - Card Game");
		setSize(800, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout(10, 10));
	}

	private JPanel createDealerPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel label = new JLabel("Dealer's Card", SwingConstants.CENTER);
		label.setFont(new Font("Arial", Font.BOLD, 18));
		label.setForeground(Color.WHITE);
		panel.add(label, BorderLayout.NORTH);

		dealerCardPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		dealerCardPanel.setBackground(new Color(0, 100, 0));
		dealerCardPanel.setPreferredSize(new Dimension(800, 150));
		panel.add(dealerCardPanel, BorderLayout.CENTER);

		return panel;
	}

	private JPanel createCenterPanel() {
		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(0, 120, 0));
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);

		balanceLabel = createLabel("Balance: $" + String.format("%.2f", player.balance), 24, Color.YELLOW);
		addComponent(panel, balanceLabel, gbc, 0, 0, 2);

		messageLabel = createLabel("Place your wager and deal!", 20, Color.WHITE);
		addComponent(panel, messageLabel, gbc, 0, 1, 2);

		wagerLabel = createLabel("Current Wager: $0", 18, Color.WHITE);
		addComponent(panel, wagerLabel, gbc, 0, 2, 2);

		cardsLeftLabel = createLabel("Cards Left in Deck: " + deck.cards.size(), 16, Color.CYAN);
		addComponent(panel, cardsLeftLabel, gbc, 0, 3, 2);

		return panel;
	}

	private JPanel createPlayerPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 100, 0));

		playerCardPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		playerCardPanel.setBackground(new Color(0, 100, 0));
		playerCardPanel.setPreferredSize(new Dimension(800, 150));
		panel.add(playerCardPanel, BorderLayout.NORTH);

		JLabel label = new JLabel("Your Card", SwingConstants.CENTER);
		label.setFont(new Font("Arial", Font.BOLD, 18));
		label.setForeground(Color.WHITE);
		panel.add(label, BorderLayout.CENTER);

		panel.add(createControlPanel(), BorderLayout.SOUTH);

		return panel;
	}

	private JPanel createControlPanel() {
		JPanel panel = new JPanel(new FlowLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel wagerInputLabel = new JLabel("Wager: $");
		wagerInputLabel.setForeground(Color.WHITE);
		wagerInputLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(wagerInputLabel);

		wagerField = new JTextField("10", 8);
		panel.add(wagerField);

		dealButton = new JButton("Deal Cards");
		dealButton.setFont(new Font("Arial", Font.BOLD, 14));
		dealButton.addActionListener(e -> startRound());
		panel.add(dealButton);

		continueWarButton = new JButton("Continue War (Double Wager)");
		continueWarButton.setFont(new Font("Arial", Font.BOLD, 14));
		continueWarButton.addActionListener(e -> continueWar());
		continueWarButton.setVisible(false);
		panel.add(continueWarButton);

		surrenderButton = new JButton("Surrender (Lose 50%)");
		surrenderButton.setFont(new Font("Arial", Font.BOLD, 14));
		surrenderButton.addActionListener(e -> surrender());
		surrenderButton.setVisible(false);
		panel.add(surrenderButton);

		return panel;
	}

	private void startRound() {
		if (!validateAndSetWager()) {
			return;
		}

		checkAndReshuffleDeck();
		disableControls();
		clearCardPanels();

		messageLabel.setText("Dealing cards...");
		animateDeal();
	}

	private boolean validateAndSetWager() {
		try {
			double wager = Double.parseDouble(wagerField.getText());
			if (wager <= 0) {
				showError("Wager must be positive!");
				return false;
			}
			if (wager > player.balance) {
				showError("Insufficient balance!");
				return false;
			}
			currentWager = (int) wager;
			player.balance -= currentWager;
			updateBalanceAndSave();
			wagerLabel.setText("Current Wager: $" + currentWager);
			updateCardsLeft();
			return true;
		} catch (NumberFormatException e) {
			showError("Invalid wager amount!");
			return false;
		}
	}

	private void checkAndReshuffleDeck() {
		if (deck.cards.size() < 10) {
			this.deck = createWarDeck();
			messageLabel.setText("Deck reshuffled!");
			updateCardsLeft();
		}
	}

	private void animateDeal() {
		Timer dealTimer = new Timer(1000, null);
		final int[] step = { 0 };

		dealTimer.addActionListener(e -> {
			if (step[0] == 0) {
				dealPlayerCard();
				step[0]++;
			} else if (step[0] == 1) {
				dealDealerCard();
				step[0]++;
			} else {
				dealTimer.stop();
				evaluateRound();
			}
		});

		dealTimer.start();
	}

	private void dealPlayerCard() {
		playerCard = deck.deal(deck);
		playerCardPanel.add(new CardPanel(playerCard));
		playerCardPanel.revalidate();
		playerCardPanel.repaint();
		messageLabel.setText("Your card dealt!");
		updateCardsLeft();
	}

	private void dealDealerCard() {
		dealerCard = deck.deal(deck);
		dealerCardPanel.add(new CardPanel(dealerCard));
		dealerCardPanel.revalidate();
		dealerCardPanel.repaint();
		messageLabel.setText("Dealer's card dealt!");
		updateCardsLeft();
	}

	private void evaluateRound() {
		int playerValue = playerCard.worth;
		int dealerValue = dealerCard.worth;

		if (playerValue > dealerValue) {
			handleWin();
		} else if (dealerValue > playerValue) {
			handleLoss();
		} else {
			handleWar();
		}
	}

	private void handleWin() {
		player.balance += currentWager * 2;
		updateBalanceAndSave();
		setMessage("🎉 YOU WIN! 🎉", Color.GREEN);
		resetForNextRound();
	}

	private void handleLoss() {
		updateBalanceAndSave();
		setMessage("😞 Dealer Wins!", Color.RED);
		resetForNextRound();
	}

	private void handleWar() {
		setMessage("⚔️ WAR! ⚔️ Cards are equal!", Color.ORANGE);
		showWarButtons(true);
	}

	private void continueWar() {
		if (currentWager * 2 > player.balance) {
			JOptionPane.showMessageDialog(this, "Insufficient balance to double wager!\nYou must surrender.",
					"Cannot Continue", JOptionPane.WARNING_MESSAGE);
			return;
		}

		player.balance -= currentWager;
		currentWager *= 2;
		updateBalanceAndSave();
		wagerLabel.setText("Current Wager: $" + currentWager);

		showWarButtons(false);
		setMessage("War continues! Dealing new cards...", Color.WHITE);
		clearCardPanels();
		animateDeal();
	}

	private void surrender() {
		player.balance += currentWager / 2;
		updateBalanceAndSave();
		setMessage("You surrendered. 50% of wager returned.", Color.YELLOW);
		showWarButtons(false);
		resetForNextRound();
	}

	private void resetForNextRound() {
		currentWager = 0;
		wagerLabel.setText("Current Wager: $0");

		Timer resetTimer = new Timer(3000, e -> {
			enableControls();
			setMessage("Place your wager and deal!", Color.WHITE);
			showWarButtons(false);
		});
		resetTimer.setRepeats(false);
		resetTimer.start();
	}

	private Deck createWarDeck() {
		Deck warDeck = new Deck();
		warDeck.cards.clear();

		String[] types = { "♥", "♦", "♠", "♣" };
		String[] display = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 13; j++) {
				Cards card = new Cards(j, types[i], display[j]);
				warDeck.cards.add(card);
			}
		}

		warDeck.shuffle();
		return warDeck;
	}

	// Helper methods
	private JLabel createLabel(String text, int fontSize, Color color) {
		JLabel label = new JLabel(text);
		label.setFont(new Font("Arial", Font.BOLD, fontSize));
		label.setForeground(color);
		return label;
	}

	private void addComponent(JPanel panel, JLabel component, GridBagConstraints gbc, int x, int y, int width) {
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = width;
		panel.add(component, gbc);
	}

	private void setMessage(String text, Color color) {
		messageLabel.setText(text);
		messageLabel.setForeground(color);
	}

	private void showWarButtons(boolean show) {
		continueWarButton.setVisible(show);
		surrenderButton.setVisible(show);
	}

	private void disableControls() {
		dealButton.setEnabled(false);
		wagerField.setEnabled(false);
	}

	private void enableControls() {
		dealButton.setEnabled(true);
		wagerField.setEnabled(true);
	}

	private void clearCardPanels() {
		dealerCardPanel.removeAll();
		playerCardPanel.removeAll();
	}

	private void showError(String message) {
		JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void updateBalanceAndSave() {
		try {
			player.updateBalance(player.balance);
			balanceLabel.setText("Balance: $" + String.format("%.2f", player.balance));
		} catch (Exception e) {
			setMessage("Error saving balance!", Color.RED);
			e.printStackTrace();
		}
	}

	private void updateCardsLeft() {
		cardsLeftLabel.setText("Cards Left in Deck: " + deck.cards.size());
	}
}