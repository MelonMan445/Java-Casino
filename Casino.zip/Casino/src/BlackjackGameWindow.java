
/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

public class BlackjackGameWindow extends JFrame {
	// Game state
	private Player player;
	private Deck deck;
	private ArrayList<Hand> playerHands;
	private Hand dealerHand;
	private int currentHandIndex;
	private int baseWager;
	private boolean insuranceTaken;
	private int insuranceAmount;

	// UI Components
	private JPanel dealerPanel;
	private JPanel playerHandsPanel;
	private JLabel balanceLabel;
	private JLabel messageLabel;
	private JLabel cardsLeftLabel;
	private JButton dealButton;
	private JButton hitButton;
	private JButton standButton;
	private JButton doubleButton;
	private JButton splitButton;
	private JTextField wagerField;

	public BlackjackGameWindow(Player player) {
		this.player = player;
		this.deck = createBlackjackDeck();
		this.playerHands = new ArrayList<>();
		this.dealerHand = new Hand(0);
		this.currentHandIndex = 0;
		initializeUI();
	}

	private void initializeUI() {
		setupFrame();
		add(createTopPanel(), BorderLayout.NORTH);
		add(createCenterPanel(), BorderLayout.CENTER);
		add(createBottomPanel(), BorderLayout.SOUTH);
		setVisible(true);
	}

	private void setupFrame() {
		setTitle("Blackjack");
		setSize(1000, 700);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout(10, 10));
	}

	private JPanel createTopPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel dealerLabel = new JLabel("Dealer's Hand", SwingConstants.CENTER);
		dealerLabel.setFont(new Font("Arial", Font.BOLD, 18));
		dealerLabel.setForeground(Color.WHITE);
		panel.add(dealerLabel, BorderLayout.NORTH);

		dealerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		dealerPanel.setBackground(new Color(0, 100, 0));
		dealerPanel.setPreferredSize(new Dimension(1000, 150));
		panel.add(dealerPanel, BorderLayout.CENTER);

		return panel;
	}

	private JPanel createCenterPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 120, 0));

		balanceLabel = new JLabel("Balance: $" + String.format("%.2f", player.balance), SwingConstants.CENTER);
		balanceLabel.setFont(new Font("Arial", Font.BOLD, 24));
		balanceLabel.setForeground(Color.YELLOW);
		panel.add(balanceLabel, BorderLayout.NORTH);

		messageLabel = new JLabel("Place your wager and deal!", SwingConstants.CENTER);
		messageLabel.setFont(new Font("Arial", Font.BOLD, 20));
		messageLabel.setForeground(Color.WHITE);
		panel.add(messageLabel, BorderLayout.CENTER);

		cardsLeftLabel = new JLabel("Cards Left in Deck: " + deck.cards.size(), SwingConstants.CENTER);
		cardsLeftLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		cardsLeftLabel.setForeground(Color.CYAN);
		panel.add(cardsLeftLabel, BorderLayout.SOUTH);

		return panel;
	}

	private JPanel createBottomPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel playerLabel = new JLabel("Your Hand(s)", SwingConstants.CENTER);
		playerLabel.setFont(new Font("Arial", Font.BOLD, 18));
		playerLabel.setForeground(Color.WHITE);
		panel.add(playerLabel, BorderLayout.NORTH);

		playerHandsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		playerHandsPanel.setBackground(new Color(0, 100, 0));
		playerHandsPanel.setPreferredSize(new Dimension(1000, 200));
		panel.add(playerHandsPanel, BorderLayout.CENTER);

		panel.add(createControlPanel(), BorderLayout.SOUTH);

		return panel;
	}

	private JPanel createControlPanel() {
		JPanel panel = new JPanel(new FlowLayout());
		panel.setBackground(new Color(0, 100, 0));

		JLabel wagerLabel = new JLabel("Wager: $");
		wagerLabel.setForeground(Color.WHITE);
		wagerLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(wagerLabel);

		wagerField = new JTextField("10", 8);
		panel.add(wagerField);

		dealButton = new JButton("Deal");
		dealButton.setFont(new Font("Arial", Font.BOLD, 14));
		dealButton.addActionListener(e -> startRound());
		panel.add(dealButton);

		hitButton = new JButton("Hit");
		hitButton.setFont(new Font("Arial", Font.BOLD, 14));
		hitButton.addActionListener(e -> hit());
		hitButton.setVisible(false);
		panel.add(hitButton);

		standButton = new JButton("Stand");
		standButton.setFont(new Font("Arial", Font.BOLD, 14));
		standButton.addActionListener(e -> stand());
		standButton.setVisible(false);
		panel.add(standButton);

		doubleButton = new JButton("Double Down");
		doubleButton.setFont(new Font("Arial", Font.BOLD, 14));
		doubleButton.addActionListener(e -> doubleDown());
		doubleButton.setVisible(false);
		panel.add(doubleButton);

		splitButton = new JButton("Split");
		splitButton.setFont(new Font("Arial", Font.BOLD, 14));
		splitButton.addActionListener(e -> split());
		splitButton.setVisible(false);
		panel.add(splitButton);

		return panel;
	}

	private void startRound() {
		if (!validateAndSetWager()) {
			return;
		}

		checkAndReshuffleDeck();
		resetGame();
		disableDealButton();

		messageLabel.setText("Dealing cards...");
		animateInitialDeal();
	}

	private boolean validateAndSetWager() {
		try {
			double wager = Double.parseDouble(wagerField.getText());
			if (wager <= 0) {
				showError("Wager must be positive!");
				return false;
			}
			if (wager > player.balance) {
				showError("Insufficient balance!");
				return false;
			}
			baseWager = (int) wager;
			player.balance -= baseWager;
			updateBalanceAndSave();
			updateCardsLeft();
			return true;
		} catch (NumberFormatException e) {
			showError("Invalid wager amount!");
			return false;
		}
	}

	private void checkAndReshuffleDeck() {
		if (deck.cards.size() < 20) {
			this.deck = createBlackjackDeck();
			messageLabel.setText("Deck reshuffled!");
			updateCardsLeft();
		}
	}

	private void resetGame() {
		playerHands.clear();
		playerHands.add(new Hand(baseWager));
		dealerHand = new Hand(0);
		currentHandIndex = 0;
		insuranceTaken = false;
		insuranceAmount = 0;
		dealerPanel.removeAll();
		playerHandsPanel.removeAll();
	}

	private void animateInitialDeal() {
		Timer dealTimer = new Timer(500, null);
		final int[] step = { 0 };

		dealTimer.addActionListener(e -> {
			if (step[0] == 0) {
				dealCardToPlayer(0);
				step[0]++;
			} else if (step[0] == 1) {
				dealCardToDealer(false);
				step[0]++;
			} else if (step[0] == 2) {
				dealCardToPlayer(0);
				step[0]++;
			} else if (step[0] == 3) {
				dealCardToDealer(true);
				step[0]++;
			} else {
				dealTimer.stop();
				checkInitialConditions();
			}
		});

		dealTimer.start();
	}

	private void dealCardToPlayer(int handIndex) {
		Cards card = deck.deal(deck);
		playerHands.get(handIndex).addCard(card);
		updateCardsLeft();
		displayHands();

		if (card.display_char.equals("A")) {
			chooseAceValue(handIndex);
		}
	}

	private void dealCardToDealer(boolean faceDown) {
		Cards card = deck.deal(deck);
		dealerHand.addCard(card);
		if (faceDown) {
			dealerHand.setHoleCard(true);
		}
		updateCardsLeft();
		displayDealerHand(true);
	}

	private void chooseAceValue(int handIndex) {
		int choice = JOptionPane.showOptionDialog(this, "You drew an Ace! Choose its value:", "Ace Value",
				JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] { "1", "11" }, "11");

		int value = (choice == 1 || choice == -1) ? 11 : 1;
		playerHands.get(handIndex).setLastAceValue(value);
		displayHands();
	}

	private void checkInitialConditions() {
		// Check for dealer Ace (insurance)
		if (dealerHand.cards.get(0).display_char.equals("A")) {
			offerInsurance();
		}

		// Check for player blackjack
		if (calculateHandValue(playerHands.get(0)) == 21 && playerHands.get(0).cards.size() == 2) {
			handleBlackjack();
		} else {
			enableGameButtons();
		}
	}

	private void offerInsurance() {
		int choice = JOptionPane.showConfirmDialog(this, "Dealer shows an Ace. Take insurance?\n(Costs $"
				+ (baseWager / 2) + ", pays 2:1 if dealer has Blackjack)", "Insurance", JOptionPane.YES_NO_OPTION);

		if (choice == JOptionPane.YES_OPTION) {
			insuranceAmount = baseWager / 2;
			if (insuranceAmount > player.balance) {
				showError("Insufficient balance for insurance!");
			} else {
				player.balance -= insuranceAmount;
				insuranceTaken = true;
				updateBalanceAndSave();
			}
		}
	}

	private void handleBlackjack() {
		dealerHand.setHoleCard(false);
		displayDealerHand(false);

		int dealerValue = calculateHandValue(dealerHand);
		if (dealerValue == 21) {
			messageLabel.setText("Push! Both have Blackjack");
			player.balance += baseWager;
		} else {
			messageLabel.setText("🎉 BLACKJACK! You win 3:2! 🎉");
			player.balance += baseWager + (int) (baseWager * 1.5);
		}

		if (insuranceTaken) {
			if (dealerValue == 21) {
				player.balance += insuranceAmount * 3;
			}
		}

		updateBalanceAndSave();
		enableDealButton();
	}

	private void hit() {
		dealCardToPlayer(currentHandIndex);

		int value = calculateHandValue(playerHands.get(currentHandIndex));
		if (value > 21) {
			messageLabel.setText("Hand " + (currentHandIndex + 1) + " busts!");
			nextHand();
		} else if (value == 21) {
			stand();
		} else {
			updateSplitButton();
		}
	}

	private void stand() {
		nextHand();
	}

	private void doubleDown() {
		if (baseWager > player.balance) {
			showError("Insufficient balance to double down!");
			return;
		}

		player.balance -= baseWager;
		playerHands.get(currentHandIndex).wager += baseWager;
		updateBalanceAndSave();

		dealCardToPlayer(currentHandIndex);

		if (calculateHandValue(playerHands.get(currentHandIndex)) <= 21) {
			nextHand();
		} else {
			messageLabel.setText("Hand " + (currentHandIndex + 1) + " busts after double!");
			Timer timer = new Timer(1500, e -> nextHand());
			timer.setRepeats(false);
			timer.start();
		}
	}

	private void split() {
		if (baseWager > player.balance) {
			showError("Insufficient balance to split!");
			return;
		}

		player.balance -= baseWager;
		updateBalanceAndSave();

		Hand currentHand = playerHands.get(currentHandIndex);
		Cards secondCard = currentHand.cards.remove(1);

		Hand newHand = new Hand(baseWager);
		newHand.addCard(secondCard);

		playerHands.add(currentHandIndex + 1, newHand);

		dealCardToPlayer(currentHandIndex);
		dealCardToPlayer(currentHandIndex + 1);

		displayHands();
		updateSplitButton();
	}

	private void nextHand() {
		currentHandIndex++;

		if (currentHandIndex < playerHands.size()) {
			messageLabel.setText("Playing Hand " + (currentHandIndex + 1));
			displayHands();
			updateSplitButton();
		} else {
			playDealer();
		}
	}

	private void playDealer() {
		disableGameButtons();
		dealerHand.setHoleCard(false);
		displayDealerHand(false);

		messageLabel.setText("Dealer's turn...");

		Timer dealerTimer = new Timer(1000, null);
		dealerTimer.addActionListener(e -> {
			int dealerValue = calculateHandValue(dealerHand);

			if (dealerValue < 17) {
				Cards card = deck.deal(deck);
				dealerHand.addCard(card);
				updateCardsLeft();
				displayDealerHand(false);
			} else {
				dealerTimer.stop();
				resolveAllHands();
			}
		});
		dealerTimer.start();
	}

	private void resolveAllHands() {
		int dealerValue = calculateHandValue(dealerHand);
		StringBuilder result = new StringBuilder();

		for (int i = 0; i < playerHands.size(); i++) {
			Hand hand = playerHands.get(i);
			int handValue = calculateHandValue(hand);

			if (handValue > 21) {
				result.append("Hand ").append(i + 1).append(": Bust | ");
			} else if (dealerValue > 21) {
				result.append("Hand ").append(i + 1).append(": Win! | ");
				player.balance += hand.wager * 2;
			} else if (handValue > dealerValue) {
				result.append("Hand ").append(i + 1).append(": Win! | ");
				player.balance += hand.wager * 2;
			} else if (handValue == dealerValue) {
				result.append("Hand ").append(i + 1).append(": Push | ");
				player.balance += hand.wager;
			} else {
				result.append("Hand ").append(i + 1).append(": Lose | ");
			}
		}

		messageLabel.setText(result.toString());
		updateBalanceAndSave();
		enableDealButton();
	}

	private void displayHands() {
		playerHandsPanel.removeAll();

		for (int i = 0; i < playerHands.size(); i++) {
			JPanel handPanel = createHandPanel(playerHands.get(i), i);
			playerHandsPanel.add(handPanel);
		}

		playerHandsPanel.revalidate();
		playerHandsPanel.repaint();
	}

	private JPanel createHandPanel(Hand hand, int index) {
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panel.setBackground(new Color(0, 80, 0));

		if (index == currentHandIndex) {
			panel.setBorder(new LineBorder(Color.YELLOW, 3));
		} else {
			panel.setBorder(new LineBorder(Color.WHITE, 1));
		}

		for (Cards card : hand.cards) {
			panel.add(new CardPanel(card));
		}

		JLabel valueLabel = new JLabel("Value: " + calculateHandValue(hand));
		valueLabel.setForeground(Color.WHITE);
		valueLabel.setFont(new Font("Arial", Font.BOLD, 14));
		panel.add(valueLabel);

		return panel;
	}

	private void displayDealerHand(boolean hideHole) {
		dealerPanel.removeAll();

		for (int i = 0; i < dealerHand.cards.size(); i++) {
			if (i == 1 && hideHole && dealerHand.hasHoleCard) {
				JPanel hiddenCard = new JPanel();
				hiddenCard.setPreferredSize(new Dimension(80, 120));
				hiddenCard.setBackground(Color.DARK_GRAY);
				hiddenCard.setBorder(new LineBorder(Color.BLACK, 2));
				dealerPanel.add(hiddenCard);
			} else {
				dealerPanel.add(new CardPanel(dealerHand.cards.get(i)));
			}
		}

		if (!hideHole || !dealerHand.hasHoleCard) {
			JLabel valueLabel = new JLabel("Value: " + calculateHandValue(dealerHand));
			valueLabel.setForeground(Color.WHITE);
			valueLabel.setFont(new Font("Arial", Font.BOLD, 14));
			dealerPanel.add(valueLabel);
		}

		dealerPanel.revalidate();
		dealerPanel.repaint();
	}

	private int calculateHandValue(Hand hand) {
		int value = 0;
		int aceIndex = 0;

		for (Cards card : hand.cards) {
			if (card.display_char.equals("A")) {
				if (aceIndex < hand.aceValues.size()) {
					value += hand.aceValues.get(aceIndex);
					aceIndex++;
				} else {
					value += 11; // Default to 11 if no value set
				}
			} else {
				value += card.worth;
			}
		}

		return value;
	}

	private void updateSplitButton() {
		Hand currentHand = playerHands.get(currentHandIndex);
		boolean canSplit = currentHand.cards.size() == 2
				&& currentHand.cards.get(0).worth == currentHand.cards.get(1).worth && player.balance >= baseWager;
		splitButton.setVisible(canSplit);
	}

	private void enableGameButtons() {
		hitButton.setVisible(true);
		standButton.setVisible(true);
		doubleButton.setVisible(player.balance >= baseWager && playerHands.get(currentHandIndex).cards.size() == 2);
		updateSplitButton();
		displayHands();
	}

	private void disableGameButtons() {
		hitButton.setVisible(false);
		standButton.setVisible(false);
		doubleButton.setVisible(false);
		splitButton.setVisible(false);
	}

	private void enableDealButton() {
		Timer timer = new Timer(3000, e -> {
			dealButton.setEnabled(true);
			wagerField.setEnabled(true);
			messageLabel.setText("Place your wager and deal!");
		});
		timer.setRepeats(false);
		timer.start();
	}

	private void disableDealButton() {
		dealButton.setEnabled(false);
		wagerField.setEnabled(false);
	}

	private Deck createBlackjackDeck() {
		Deck bjDeck = new Deck();
		bjDeck.cards.clear();

		String[] types = { "♥", "♦", "♠", "♣" };
		String[] display = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
		int[] values = { 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10 };

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 13; j++) {
				Cards card = new Cards(values[j], types[i], display[j]);
				bjDeck.cards.add(card);
			}
		}

		bjDeck.shuffle();
		return bjDeck;
	}

	private void showError(String message) {
		JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void updateBalanceAndSave() {
		try {
			player.updateBalance(player.balance);
			balanceLabel.setText("Balance: $" + String.format("%.2f", player.balance));
		} catch (Exception e) {
			messageLabel.setText("Error saving balance!");
			e.printStackTrace();
		}
	}

	private void updateCardsLeft() {
		cardsLeftLabel.setText("Cards Left in Deck: " + deck.cards.size());
	}

	// Inner class to represent a hand
	private class Hand {
		ArrayList<Cards> cards;
		ArrayList<Integer> aceValues;
		int wager;
		boolean hasHoleCard;

		Hand(int wager) {
			this.cards = new ArrayList<>();
			this.aceValues = new ArrayList<>();
			this.wager = wager;
			this.hasHoleCard = false;
		}

		void addCard(Cards card) {
			cards.add(card);
		}

		void setLastAceValue(int value) {
			aceValues.add(value);
		}

		void setHoleCard(boolean hasHole) {
			this.hasHoleCard = hasHole;
		}
	}
}