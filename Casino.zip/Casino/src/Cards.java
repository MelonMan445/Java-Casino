/**
 * @author Jonathan Laporte
 * @version 2025-12-22
 */

/**
 * 
 */
public class Cards {
	int worth;
	String type;
	String display_char;

	public Cards(int worth, String type, String display_char) {
		this.worth = worth;
		this.type = type;
		this.display_char = display_char;
	}
}
